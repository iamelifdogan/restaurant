from django.db import models

# Create your models here.


class Category(models.Model):
   title = models.CharField(("Kategori Başlığı"), max_length=50)
   
   def __str__(self) -> str:
      return self.title


class Post(models.Model):
   category = models.ForeignKey(Category, verbose_name=("Kategori"), on_delete=models.SET_NULL, null=True)
   title = models.CharField(("Başlık"), max_length=100, null=True)
   date_now = models.DateField(("Tarih"), auto_now_add=True)
   text = models.TextField(("İçerik"))
   image = models.FileField(("Resim"), upload_to="post", max_length=100)

   def __str__(self) -> str:
        return self.title
     
class Comment(models.Model):
   post = models.ForeignKey(Post, verbose_name=("Hangi posta ait"), on_delete=models.CASCADE, null=True)
   full_name = models.CharField(("Ad Soyad"), max_length=50)
   text = models.TextField(("Yorum"))
   date_now = models.DateTimeField(("Tarih - Saat"), auto_now_add=True, null=True)
   image = models.FileField(("Profil resmi"), upload_to=" ", max_length=100,  null=True)

   def __str__(self) -> str:
      return self.full_name

class Image(models.Model):
   image = models.ImageField(("Image"), upload_to="", max_length=400)

   def __str__(self) -> str:
      return self.image.name
   
class MenuCategory(models.Model):
    title = models.CharField(("Menü Kategorisi"), max_length=50)
    
    def __str__(self) -> str:
        return self.title

class Menu(models.Model):
   category = models.ForeignKey(MenuCategory, verbose_name=("Menü Kategorisi"), on_delete=models.SET_NULL, null=True)
   name = models.CharField(("Yemek İsimleri"), max_length=150)
   price = models.FloatField(("Fiyat"))
   description = models.TextField(("İçerik"))

   def __str__(self) -> str:
        return self.name