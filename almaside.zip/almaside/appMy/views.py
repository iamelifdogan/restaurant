from django.shortcuts import render
from .models import *

# Create your views here.

def indexPage(request ):
    posts = Post.objects.all()
    
    context = {
        "posts": posts,
    }
    return render(request, 'index.html', context)

def detailPage(request, pid):
    comments = Comment.objects.filter(post=pid)
    post = Post.objects.get(id=pid)
    
    if request.method == "POST":
        fullname = request.POST.get("fullname")
        text = request.POST.get("comment")

        comment = Comment(full_name=fullname, text=text, post=post)
        comment.save()
    
    context = {   
        "post": post,
        "categorys": Category.objects.all(),
        "posts" : Post.objects.all().order_by("?")[:5],
        "comments": comments,
    }
    return render(request, 'detail.html', context)

def menuPage(request):
    cold_starters = Menu.objects.filter(category__title__contains='Başlangıçlar')
    warm_starters = Menu.objects.filter(category__title__contains='Ara Sıcaklar')
    main_courses = Menu.objects.filter(category__title__contains='Ana Yemekler')
    sushi = Menu.objects.filter(category__title__contains='Sushiler')
    from_stone_oven = Menu.objects.filter(category__title__contains='Taş Fırından')
    pasta_risotto = Menu.objects.filter(category__title__contains='Makarna & Rizotto')
    desserts = Menu.objects.filter(category__title__contains='Tatlılar')
    
    context = {
        "cold_starters": cold_starters,
        "warm_starters": warm_starters,
        "main_courses": main_courses,
        "sushi": sushi,
        "from_stone_oven": from_stone_oven,
        "pasta_risotto": pasta_risotto,
        "desserts": desserts,
    }
    return render(request, 'menu.html', context)

def aboutPage(request):
    context = {}
    return render(request, 'about.html', context)

def galeriPage(request):
    images = Image.objects.all()
    
    context = {
        "images": images,
    }
    return render(request, 'galeri.html', context)


def contactPage(request):
    context = {}
    return render(request, 'contact.html', context)

def errorPage(request):
    context = {}
    return render(request, 'error.html', context)