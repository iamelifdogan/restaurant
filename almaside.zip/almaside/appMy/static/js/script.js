// Anasayfa Javascript Kodları Start

// MODAL

// Arama modalını aç
function openSearchModal() {
    document.getElementById('searchModal').style.display = 'block';
}

// Arama modalını kapat
document.getElementsByClassName('close')[0].addEventListener('click', function() {
    document.getElementById('searchModal').style.display = 'none';
});

// Kullanıcı modalın dışına tıklarsa modalı kapat
window.addEventListener('click', function(event) {
    if (event.target === document.getElementById('searchModal')) {
        document.getElementById('searchModal').style.display = 'none';
    }
});

function toggleIndicator(link) {
    var allLinks = document.querySelectorAll('.navbar-link');
    allLinks.forEach(function (el) {
        el.classList.remove('clicked');
    });

    link.classList.add('clicked');
}

// Hamburger menü

const openNavSidebar = document.getElementById('open-nav-sidebar');
const sidebarContainer = document.querySelector('.sidebar-container-navigation');
const sidebarCloseButton = document.getElementById('sidebar-navigation-close');

openNavSidebar.addEventListener('click', () => {
  sidebarContainer.classList.add('slidebar-show');
});

sidebarCloseButton.addEventListener('click', () => {
  sidebarContainer.classList.remove('slidebar-show');
});

// SCROLL ANİMASYON

// About Images Animasyon 1

function reveal() {
    var reveals = document.querySelectorAll(".reveal");
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var elementTop = reveals[i].getBoundingClientRect().top;
      var elementVisible = 250;
  
      if (elementTop < windowHeight - elementVisible) {
        reveals[i].classList.add("active");
      } else {
        reveals[i].classList.remove("active");
      }
    }
  }
  
  window.addEventListener("scroll", reveal);

//   =============================================

// About Images Animasyon 2

function reveall() {
    var reveals = document.querySelectorAll(".reveall");
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var elementTop = reveals[i].getBoundingClientRect().top;
      var elementVisible = 300;
  
      if (elementTop < windowHeight - elementVisible) {
        reveals[i].classList.add("active");
      } else {
        reveals[i].classList.remove("active");
      }
    }
  }
  
  window.addEventListener("scroll", reveall);

//   ===============================

// About Button Animasyon

function abtn() {
    var abtns = document.querySelectorAll(".abtn");
  
    for (var i = 0; i < abtns.length; i++) {
      var windowHeight = window.innerHeight;
      var elementTop = abtns[i].getBoundingClientRect().top;
      var elementVisible = 140;
  
      if (elementTop < windowHeight - elementVisible) {
        abtns[i].classList.add("active");
      } else {
        abtns[i].classList.remove("active");
      }
    }
  }
  
  window.addEventListener("scroll", abtn);

//   ========================

// Anasayfa Javascript Kodları End

// =============================================================================================================

// About HTML Javascript Kodları Start


$(document).ready(function () {
  if (renderPage) {
      $('body').addClass('loaded');
  }

  setCarousel();

  $(window).resize(function () {
      setCarousel();
  });

  $('.nav-link').click(function () {
      $('#mainNav').removeClass('show');
  });

  $('a[href*="#"]')
      .not('[href="#"]')
      .not('[href="#0"]')
      .click(function (event) {
          if (
              location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '')
              &&
              location.hostname == this.hostname
          ) {
              var target = $(this.hash);
              target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
              if (target.length) {
                  event.preventDefault();
                  $('html, body').animate({
                      scrollTop: target.offset().top + 1
                  }, 1000, function () {
                      var $target = $(target);
                      $target.focus();
                      if ($target.is(":focus")) {
                          return false;
                      } else {
                          $target.attr('tabindex', '-1');
                          $target.focus();
                      };
                  });
              }
          }
      });
});

// ======================