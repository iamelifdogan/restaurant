from django.contrib import admin
from appMy.models import *

# Register your models here.


admin.site.register(Post)
admin.site.register(Category)
admin.site.register(Comment)
admin.site.register(Image)
admin.site.register(MenuCategory)
admin.site.register(Menu)